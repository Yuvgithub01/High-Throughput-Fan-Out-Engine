# High-Throughput Fan-Out Engine

Java 21 backend assignment implementation for a streaming fan-out engine that reads a large flat file and dispatches every record to multiple downstream sink types with transformation, throttling, retry, backpressure, and observability.

## Setup Instructions

### Prerequisites
- Java 21+
- Maven 3.9+

### Build
```bash
mvn clean test
mvn clean package
```

### Run
```bash
java -jar target/high-throughput-fan-out-engine-1.0.0.jar src/main/resources/application.yaml
```

The app streams from the configured source and writes DLQ entries to the configured `engine.dlqPath`.

## Architecture Diagram (Textual)

`RecordReader (CSV/JSONL/FIXED, streaming line-by-line)`  
`-> Orchestrator`  
`-> per-sink Transformer Strategy`  
`-> bounded per-sink BlockingQueue (backpressure)`  
`-> virtual-thread sink workers`  
`-> rate-limited mock sinks (REST / gRPC / MQ / Wide-column DB)`  
`-> success metrics OR DLQ on terminal failure`

Detailed notes: `docs/ARCHITECTURE.md`

## Design Decisions

- **Backpressure**: Each sink has a bounded `LinkedBlockingQueue`; producer `put()` blocks when slow sinks lag, preventing unbounded memory growth.
- **Concurrency model**: Sink workers run on virtual-thread executors (`Executors.newVirtualThreadPerTaskExecutor`) so sinks execute independently and scale with available cores.
- **Retry + resilience**: Max retry count is config-driven (`engine.maxRetries`), with terminal failures written to a JSONL DLQ.
- **Extensibility**: Core orchestrator does not depend on concrete sinks. New sinks only require adding a `Sink`, a `SinkTransformer`, and factory mapping.

## Assumptions

- CSV parsing uses delimiter split and does not implement full RFC quoted-field handling.
- Protobuf payload is represented as serialized `Struct` bytes for mock gRPC sink simulation.
- Downstream systems are mocked; no external infrastructure is required.

## Config + Sample Input

- Config: `src/main/resources/application.yaml`
- Sample CSV: `sample-data/input.csv`
- Sample JSONL: `sample-data/input.jsonl`
- Sample fixed-width: `sample-data/input.fixed`

## AI Tooling Prompts

Prompt history used for this submission is documented in `docs/prompts.md`.
