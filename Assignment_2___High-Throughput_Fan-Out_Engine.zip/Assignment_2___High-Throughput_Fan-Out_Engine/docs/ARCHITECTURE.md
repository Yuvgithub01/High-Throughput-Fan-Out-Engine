# Architecture Notes

## Components

- `ConfigLoader`: Loads YAML config for source, sinks, rate limits, retries, and queue sizes.
- `RecordReaderFactory`: Creates streaming readers (`CSV`, `JSONL`, `FIXED`).
- `TransformerFactory`: Strategy pattern for sink-specific payload formats.
- `SinkFactory`: Factory pattern for sink simulation classes.
- `FanOutOrchestrator`: Core fan-out coordinator.
- `SinkWorker`: Queue consumer with retry and DLQ handling.
- `MetricsCollector`: 5-second periodic status logs.
- `FileDeadLetterQueue`: Durable terminal-failure tracking in JSONL.

## Data Flow

1. Read one source record at a time from file.
2. Transform record independently for each configured sink.
3. Put each transformed payload into that sink's bounded queue.
4. Sink worker consumes from queue, rate-limits send, retries if needed.
5. On final failure (after max retries), write a DLQ entry.
6. Print metrics every configured interval.

## Zero Data Loss Accounting

For each `sourceRecord x sink` pair, state ends as exactly one of:
- success
- terminal failure + DLQ entry

`inFlight` counter tracks active units until terminal completion.

## Concurrency

- Source ingestion is single-pass streaming.
- Each sink has isolated worker concurrency (`workers` in config).
- Workers run on virtual threads for scalable parallelism.

## Backpressure

Bounded `LinkedBlockingQueue` per sink ensures memory is bounded. If sink throughput falls behind, producer blocks on queue `put()`, naturally reducing ingestion rate.
