# AI Prompts Used

1. "Read the assignment PDF and implement the full Java solution in this repository."
2. "Design a streaming fan-out architecture with sink-specific transformations and bounded backpressure queues."
3. "Implement retries (max 3), rate limiting per sink, and DLQ for terminal failures."
4. "Add unit tests for transformers and an orchestrator integration test using Mockito."
5. "Create README documentation with setup, architecture, decisions, assumptions, and prompt log."
