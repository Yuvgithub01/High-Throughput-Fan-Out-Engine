package com.fanoutengine.dlq;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.model.DeadLetterEntry;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public final class FileDeadLetterQueue implements DeadLetterQueue {
    private final ObjectMapper objectMapper;
    private final BufferedWriter writer;
    private final Object lock = new Object();

    public FileDeadLetterQueue(ObjectMapper objectMapper, Path path) throws Exception {
        this.objectMapper = objectMapper;
        Path parent = path.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        this.writer = Files.newBufferedWriter(
            path,
            StandardOpenOption.CREATE,
            StandardOpenOption.TRUNCATE_EXISTING,
            StandardOpenOption.WRITE
        );
    }

    @Override
    public void write(DeadLetterEntry entry) {
        synchronized (lock) {
            try {
                writer.write(objectMapper.writeValueAsString(entry));
                writer.newLine();
                writer.flush();
            } catch (Exception ex) {
                System.err.println("failed to write DLQ entry: " + ex.getMessage());
            }
        }
    }

    @Override
    public void close() throws Exception {
        writer.close();
    }
}
