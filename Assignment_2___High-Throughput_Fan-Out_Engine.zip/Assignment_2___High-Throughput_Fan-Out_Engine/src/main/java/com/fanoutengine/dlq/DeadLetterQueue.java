package com.fanoutengine.dlq;

import com.fanoutengine.model.DeadLetterEntry;

public interface DeadLetterQueue extends AutoCloseable {
    void write(DeadLetterEntry entry);

    @Override
    void close() throws Exception;
}
