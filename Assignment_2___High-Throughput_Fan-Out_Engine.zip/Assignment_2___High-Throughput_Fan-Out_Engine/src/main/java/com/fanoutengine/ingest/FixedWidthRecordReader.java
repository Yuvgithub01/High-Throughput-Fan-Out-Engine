package com.fanoutengine.ingest;

import com.fanoutengine.config.AppConfig;
import com.fanoutengine.model.SourceRecord;
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class FixedWidthRecordReader implements RecordReader {
    private final BufferedReader reader;
    private final List<AppConfig.FixedWidthColumn> columns;

    public FixedWidthRecordReader(Path path, List<AppConfig.FixedWidthColumn> columns) throws Exception {
        this.reader = Files.newBufferedReader(path);
        this.columns = columns;
    }

    @Override
    public void readAll(RecordConsumer consumer) throws Exception {
        String line;
        long lineNumber = 0;
        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (line.isBlank()) {
                continue;
            }

            Map<String, Object> fields = new LinkedHashMap<>();
            for (AppConfig.FixedWidthColumn column : columns) {
                int start = Math.min(column.getStart(), line.length());
                int end = Math.min(column.getEnd(), line.length());
                String value = start >= end ? "" : line.substring(start, end).trim();
                fields.put(column.getName(), value);
            }
            consumer.accept(new SourceRecord(lineNumber, fields));
        }
    }

    @Override
    public void close() throws Exception {
        reader.close();
    }
}
