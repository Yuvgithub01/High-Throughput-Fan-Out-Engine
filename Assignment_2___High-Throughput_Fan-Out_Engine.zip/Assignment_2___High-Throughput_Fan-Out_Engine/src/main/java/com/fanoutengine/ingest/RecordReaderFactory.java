package com.fanoutengine.ingest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.config.AppConfig;
import java.nio.file.Path;

public final class RecordReaderFactory {
    private final ObjectMapper objectMapper;

    public RecordReaderFactory(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public RecordReader create(AppConfig.SourceConfig sourceConfig) throws Exception {
        Path path = Path.of(sourceConfig.getPath());
        return switch (sourceConfig.getFormat()) {
            case CSV -> new CsvRecordReader(path, sourceConfig.getDelimiter(), sourceConfig.isHasHeader());
            case JSONL -> new JsonlRecordReader(path, objectMapper);
            case FIXED -> new FixedWidthRecordReader(path, sourceConfig.getFixedWidthColumns());
        };
    }
}
