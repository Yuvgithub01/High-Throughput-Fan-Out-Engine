package com.fanoutengine.ingest;

public interface RecordReader extends AutoCloseable {
    void readAll(RecordConsumer consumer) throws Exception;

    @Override
    void close() throws Exception;
}
