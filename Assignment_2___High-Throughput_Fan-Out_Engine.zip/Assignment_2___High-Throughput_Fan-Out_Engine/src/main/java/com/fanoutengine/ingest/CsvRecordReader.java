package com.fanoutengine.ingest;

import com.fanoutengine.model.SourceRecord;
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class CsvRecordReader implements RecordReader {
    private final BufferedReader reader;
    private final String delimiter;
    private final boolean hasHeader;

    public CsvRecordReader(Path path, String delimiter, boolean hasHeader) throws Exception {
        this.reader = Files.newBufferedReader(path);
        this.delimiter = delimiter;
        this.hasHeader = hasHeader;
    }

    @Override
    public void readAll(RecordConsumer consumer) throws Exception {
        String line;
        long lineNumber = 0;
        List<String> headers = new ArrayList<>();

        if (hasHeader) {
            String headerLine = reader.readLine();
            lineNumber++;
            if (headerLine == null) {
                return;
            }
            headers = parseLine(headerLine);
        }

        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (line.isBlank()) {
                continue;
            }

            List<String> values = parseLine(line);
            if (!hasHeader && headers.isEmpty()) {
                for (int i = 0; i < values.size(); i++) {
                    headers.add("col_" + i);
                }
            }

            Map<String, Object> fields = new LinkedHashMap<>();
            for (int i = 0; i < headers.size(); i++) {
                String value = i < values.size() ? values.get(i) : "";
                fields.put(headers.get(i), value);
            }

            consumer.accept(new SourceRecord(lineNumber, fields));
        }
    }

    private List<String> parseLine(String line) {
        String[] parts = line.split(java.util.regex.Pattern.quote(delimiter), -1);
        List<String> values = new ArrayList<>(parts.length);
        for (String part : parts) {
            values.add(part.trim());
        }
        return values;
    }

    @Override
    public void close() throws Exception {
        reader.close();
    }
}
