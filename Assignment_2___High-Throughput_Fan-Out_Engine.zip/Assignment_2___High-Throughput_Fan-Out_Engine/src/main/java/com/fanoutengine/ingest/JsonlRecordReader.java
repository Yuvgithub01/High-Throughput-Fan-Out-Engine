package com.fanoutengine.ingest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.model.SourceRecord;
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public final class JsonlRecordReader implements RecordReader {
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {
    };

    private final BufferedReader reader;
    private final ObjectMapper objectMapper;

    public JsonlRecordReader(Path path, ObjectMapper objectMapper) throws Exception {
        this.reader = Files.newBufferedReader(path);
        this.objectMapper = objectMapper;
    }

    @Override
    public void readAll(RecordConsumer consumer) throws Exception {
        String line;
        long lineNumber = 0;
        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (line.isBlank()) {
                continue;
            }
            Map<String, Object> fields = objectMapper.readValue(line, MAP_TYPE);
            consumer.accept(new SourceRecord(lineNumber, fields));
        }
    }

    @Override
    public void close() throws Exception {
        reader.close();
    }
}
