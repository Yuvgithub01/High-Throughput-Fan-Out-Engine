package com.fanoutengine.ingest;

import com.fanoutengine.model.SourceRecord;

@FunctionalInterface
public interface RecordConsumer {
    void accept(SourceRecord record) throws Exception;
}
