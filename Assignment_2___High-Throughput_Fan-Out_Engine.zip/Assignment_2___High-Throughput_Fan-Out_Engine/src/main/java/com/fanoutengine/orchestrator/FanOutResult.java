package com.fanoutengine.orchestrator;

import java.util.Map;

public record FanOutResult(
    long sourceRecords,
    long inFlight,
    Map<String, SinkSummary> sinkSummary
) {
    public record SinkSummary(long success, long failure, long retry) {
    }
}
