package com.fanoutengine.orchestrator;

import com.fanoutengine.model.SourceRecord;

public final class DispatchEnvelope {
    private static final DispatchEnvelope POISON = new DispatchEnvelope(null, null, 0, true);

    private final SourceRecord sourceRecord;
    private final Object payload;
    private final int attempt;
    private final boolean poison;

    private DispatchEnvelope(SourceRecord sourceRecord, Object payload, int attempt, boolean poison) {
        this.sourceRecord = sourceRecord;
        this.payload = payload;
        this.attempt = attempt;
        this.poison = poison;
    }

    public static DispatchEnvelope of(SourceRecord sourceRecord, Object payload, int attempt) {
        return new DispatchEnvelope(sourceRecord, payload, attempt, false);
    }

    public static DispatchEnvelope poison() {
        return POISON;
    }

    public DispatchEnvelope nextAttempt() {
        return of(sourceRecord, payload, attempt + 1);
    }

    public SourceRecord sourceRecord() {
        return sourceRecord;
    }

    public Object payload() {
        return payload;
    }

    public int attempt() {
        return attempt;
    }

    public boolean poison() {
        return poison;
    }
}
