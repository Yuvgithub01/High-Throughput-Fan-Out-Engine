package com.fanoutengine.orchestrator;

import com.fanoutengine.config.AppConfig;
import com.fanoutengine.dlq.DeadLetterQueue;
import com.fanoutengine.ingest.RecordReader;
import com.fanoutengine.metrics.MetricsCollector;
import com.fanoutengine.model.DeadLetterEntry;
import com.fanoutengine.model.SourceRecord;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class FanOutOrchestrator {
    private final RecordReader recordReader;
    private final List<SinkChannel> channels;
    private final AppConfig.EngineConfig engineConfig;
    private final MetricsCollector metricsCollector;
    private final DeadLetterQueue deadLetterQueue;

    public FanOutOrchestrator(
        RecordReader recordReader,
        List<SinkChannel> channels,
        AppConfig.EngineConfig engineConfig,
        MetricsCollector metricsCollector,
        DeadLetterQueue deadLetterQueue
    ) {
        this.recordReader = recordReader;
        this.channels = channels;
        this.engineConfig = engineConfig;
        this.metricsCollector = metricsCollector;
        this.deadLetterQueue = deadLetterQueue;
    }

    public FanOutResult run() throws Exception {
        ScheduledExecutorService metricsScheduler = Executors.newSingleThreadScheduledExecutor();
        metricsCollector.startConsoleReporting(metricsScheduler, engineConfig.getMetricsIntervalSeconds());

        List<ExecutorService> sinkExecutors = new ArrayList<>();
        try (recordReader; deadLetterQueue) {
            for (SinkChannel channel : channels) {
                metricsCollector.registerSink(channel.name());
                ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
                sinkExecutors.add(executor);
                for (int i = 0; i < channel.workers(); i++) {
                    executor.submit(new SinkWorker(channel, engineConfig.getMaxRetries(), metricsCollector, deadLetterQueue));
                }
            }

            recordReader.readAll(this::dispatchRecord);

            waitForTerminalState();
            stopWorkers();
            shutdownExecutors(sinkExecutors);

            metricsCollector.printSnapshot();
            return buildResult();
        } finally {
            for (ExecutorService executor : sinkExecutors) {
                executor.shutdownNow();
            }
            metricsScheduler.shutdownNow();
            closeSinks();
        }
    }

    private void dispatchRecord(SourceRecord record) throws Exception {
        metricsCollector.incrementSourceRecords();
        for (SinkChannel channel : channels) {
            try {
                Object payload = channel.transformer().transform(record);
                metricsCollector.incrementInFlight();
                channel.queue().put(DispatchEnvelope.of(record, payload, 0));
            } catch (Exception transformException) {
                metricsCollector.recordFailure(channel.name());
                deadLetterQueue.write(
                    new DeadLetterEntry(
                        channel.name(),
                        "transform",
                        transformException.getMessage(),
                        1,
                        Instant.now().toString(),
                        record.getLineNumber(),
                        record.getFields()
                    )
                );
            }
        }
    }

    private void waitForTerminalState() throws InterruptedException {
        while (metricsCollector.inFlight() > 0) {
            Thread.sleep(100);
        }
    }

    private void stopWorkers() throws InterruptedException {
        for (SinkChannel channel : channels) {
            for (int i = 0; i < channel.workers(); i++) {
                channel.queue().put(DispatchEnvelope.poison());
            }
        }
    }

    private void shutdownExecutors(List<ExecutorService> sinkExecutors) throws InterruptedException {
        for (ExecutorService executor : sinkExecutors) {
            executor.shutdown();
            if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        }
    }

    private FanOutResult buildResult() {
        Map<String, FanOutResult.SinkSummary> summary = new LinkedHashMap<>();
        for (Map.Entry<String, MetricsCollector.SinkCounters> entry : metricsCollector.sinkCounters().entrySet()) {
            MetricsCollector.SinkCounters counters = entry.getValue();
            summary.put(
                entry.getKey(),
                new FanOutResult.SinkSummary(counters.success(), counters.failure(), counters.retry())
            );
        }
        return new FanOutResult(metricsCollector.sourceRecords(), metricsCollector.inFlight(), summary);
    }

    private void closeSinks() {
        for (SinkChannel channel : channels) {
            try {
                channel.sink().close();
            } catch (Exception ex) {
                System.err.println("failed to close sink " + channel.name() + ": " + ex.getMessage());
            }
        }
    }
}
