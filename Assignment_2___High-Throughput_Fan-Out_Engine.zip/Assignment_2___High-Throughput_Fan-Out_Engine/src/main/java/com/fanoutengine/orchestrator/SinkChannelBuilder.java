package com.fanoutengine.orchestrator;

import com.fanoutengine.config.AppConfig;
import com.fanoutengine.sink.Sink;
import com.fanoutengine.sink.SinkFactory;
import com.fanoutengine.transform.SinkTransformer;
import com.fanoutengine.transform.TransformerFactory;
import java.util.ArrayList;
import java.util.List;

public final class SinkChannelBuilder {
    private final SinkFactory sinkFactory;
    private final TransformerFactory transformerFactory;

    public SinkChannelBuilder(SinkFactory sinkFactory, TransformerFactory transformerFactory) {
        this.sinkFactory = sinkFactory;
        this.transformerFactory = transformerFactory;
    }

    public List<SinkChannel> build(AppConfig config) {
        List<SinkChannel> channels = new ArrayList<>();
        for (AppConfig.SinkConfig sinkConfig : config.getSinks()) {
            if (!sinkConfig.isEnabled()) {
                continue;
            }
            Sink sink = sinkFactory.create(sinkConfig);
            SinkTransformer transformer = transformerFactory.create(sinkConfig.getType());
            channels.add(
                new SinkChannel(
                    sinkConfig.getName(),
                    sink,
                    transformer,
                    config.getEngine().getQueueCapacity(),
                    sinkConfig.getWorkers()
                )
            );
        }
        if (channels.isEmpty()) {
            throw new IllegalArgumentException("no enabled sinks found");
        }
        return channels;
    }
}
