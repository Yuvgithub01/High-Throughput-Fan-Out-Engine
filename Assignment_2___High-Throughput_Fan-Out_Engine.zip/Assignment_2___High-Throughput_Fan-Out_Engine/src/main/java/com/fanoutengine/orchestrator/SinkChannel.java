package com.fanoutengine.orchestrator;

import com.fanoutengine.sink.Sink;
import com.fanoutengine.transform.SinkTransformer;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public final class SinkChannel {
    private final String name;
    private final Sink sink;
    private final SinkTransformer transformer;
    private final BlockingQueue<DispatchEnvelope> queue;
    private final int workers;

    public SinkChannel(String name, Sink sink, SinkTransformer transformer, int queueCapacity, int workers) {
        this.name = name;
        this.sink = sink;
        this.transformer = transformer;
        this.queue = new LinkedBlockingQueue<>(queueCapacity);
        this.workers = workers;
    }

    public String name() {
        return name;
    }

    public Sink sink() {
        return sink;
    }

    public SinkTransformer transformer() {
        return transformer;
    }

    public BlockingQueue<DispatchEnvelope> queue() {
        return queue;
    }

    public int workers() {
        return workers;
    }
}
