package com.fanoutengine.orchestrator;

import com.fanoutengine.dlq.DeadLetterQueue;
import com.fanoutengine.metrics.MetricsCollector;
import com.fanoutengine.model.DeadLetterEntry;
import java.time.Instant;
import java.util.concurrent.BlockingQueue;

public final class SinkWorker implements Runnable {
    private final SinkChannel channel;
    private final int maxRetries;
    private final MetricsCollector metrics;
    private final DeadLetterQueue deadLetterQueue;

    public SinkWorker(SinkChannel channel, int maxRetries, MetricsCollector metrics, DeadLetterQueue deadLetterQueue) {
        this.channel = channel;
        this.maxRetries = maxRetries;
        this.metrics = metrics;
        this.deadLetterQueue = deadLetterQueue;
    }

    @Override
    public void run() {
        BlockingQueue<DispatchEnvelope> queue = channel.queue();
        try {
            while (true) {
                DispatchEnvelope envelope = queue.take();
                if (envelope.poison()) {
                    return;
                }

                try {
                    channel.sink().send(envelope.payload(), envelope.sourceRecord());
                    metrics.recordSuccess(channel.name());
                    metrics.decrementInFlight();
                } catch (Exception ex) {
                    if (envelope.attempt() < maxRetries) {
                        metrics.recordRetry(channel.name());
                        queue.put(envelope.nextAttempt());
                    } else {
                        metrics.recordFailure(channel.name());
                        deadLetterQueue.write(
                            new DeadLetterEntry(
                                channel.name(),
                                "sink_send",
                                ex.getMessage(),
                                envelope.attempt() + 1,
                                Instant.now().toString(),
                                envelope.sourceRecord().getLineNumber(),
                                envelope.sourceRecord().getFields()
                            )
                        );
                        metrics.decrementInFlight();
                    }
                }
            }
        } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }
}
