package com.fanoutengine;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.config.AppConfig;
import com.fanoutengine.config.ConfigLoader;
import com.fanoutengine.dlq.DeadLetterQueue;
import com.fanoutengine.dlq.FileDeadLetterQueue;
import com.fanoutengine.ingest.RecordReader;
import com.fanoutengine.ingest.RecordReaderFactory;
import com.fanoutengine.metrics.MetricsCollector;
import com.fanoutengine.orchestrator.FanOutOrchestrator;
import com.fanoutengine.orchestrator.FanOutResult;
import com.fanoutengine.orchestrator.SinkChannel;
import com.fanoutengine.orchestrator.SinkChannelBuilder;
import com.fanoutengine.sink.SinkFactory;
import com.fanoutengine.transform.TransformerFactory;
import java.nio.file.Path;
import java.util.List;

public final class Application {
    private Application() {
    }

    public static void main(String[] args) throws Exception {
        Path configPath = args.length > 0 ? Path.of(args[0]) : Path.of("src/main/resources/application.yaml");
        AppConfig config = ConfigLoader.load(configPath);

        ObjectMapper objectMapper = new ObjectMapper();
        RecordReaderFactory readerFactory = new RecordReaderFactory(objectMapper);
        SinkChannelBuilder channelBuilder = new SinkChannelBuilder(new SinkFactory(), new TransformerFactory(objectMapper));

        List<SinkChannel> channels = channelBuilder.build(config);
        RecordReader recordReader = readerFactory.create(config.getSource());
        DeadLetterQueue deadLetterQueue = new FileDeadLetterQueue(objectMapper, Path.of(config.getEngine().getDlqPath()));

        FanOutOrchestrator orchestrator = new FanOutOrchestrator(
            recordReader,
            channels,
            config.getEngine(),
            new MetricsCollector(),
            deadLetterQueue
        );
        FanOutResult result = orchestrator.run();
        System.out.println("Completed fan-out run. Source records: " + result.sourceRecords());
    }
}
