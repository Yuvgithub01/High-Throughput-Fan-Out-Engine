package com.fanoutengine.model;

import java.util.Map;

public final class DeadLetterEntry {
    private final String sinkName;
    private final String stage;
    private final String reason;
    private final int attempts;
    private final String timestamp;
    private final long lineNumber;
    private final Map<String, Object> sourceFields;

    public DeadLetterEntry(
        String sinkName,
        String stage,
        String reason,
        int attempts,
        String timestamp,
        long lineNumber,
        Map<String, Object> sourceFields
    ) {
        this.sinkName = sinkName;
        this.stage = stage;
        this.reason = reason;
        this.attempts = attempts;
        this.timestamp = timestamp;
        this.lineNumber = lineNumber;
        this.sourceFields = sourceFields;
    }

    public String getSinkName() {
        return sinkName;
    }

    public String getStage() {
        return stage;
    }

    public String getReason() {
        return reason;
    }

    public int getAttempts() {
        return attempts;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public long getLineNumber() {
        return lineNumber;
    }

    public Map<String, Object> getSourceFields() {
        return sourceFields;
    }
}
