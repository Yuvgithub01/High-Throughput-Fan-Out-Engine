package com.fanoutengine.model;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

public final class SourceRecord {
    private final long lineNumber;
    private final Map<String, Object> fields;

    public SourceRecord(long lineNumber, Map<String, Object> fields) {
        this.lineNumber = lineNumber;
        this.fields = Collections.unmodifiableMap(Objects.requireNonNull(fields, "fields"));
    }

    public long getLineNumber() {
        return lineNumber;
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public String idOrDefault() {
        Object id = fields.get("id");
        if (id == null) {
            return "line-" + lineNumber;
        }
        String value = id.toString();
        return value.isBlank() ? "line-" + lineNumber : value;
    }
}
