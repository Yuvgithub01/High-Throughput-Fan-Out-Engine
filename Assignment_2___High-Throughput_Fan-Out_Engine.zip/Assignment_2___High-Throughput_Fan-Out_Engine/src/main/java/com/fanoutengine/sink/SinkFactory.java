package com.fanoutengine.sink;

import com.fanoutengine.config.AppConfig;

public final class SinkFactory {
    public Sink create(AppConfig.SinkConfig sinkConfig) {
        return switch (sinkConfig.getType()) {
            case REST -> new MockRestSink(
                sinkConfig.getName(),
                sinkConfig.getEndpoint(),
                sinkConfig.getRateLimitPerSecond(),
                sinkConfig.getSimulatedLatencyMs(),
                sinkConfig.getFailureRate()
            );
            case GRPC -> new MockGrpcSink(
                sinkConfig.getName(),
                sinkConfig.getEndpoint(),
                sinkConfig.getRateLimitPerSecond(),
                sinkConfig.getSimulatedLatencyMs(),
                sinkConfig.getFailureRate()
            );
            case MESSAGE_QUEUE -> new MockMessageQueueSink(
                sinkConfig.getName(),
                sinkConfig.getEndpoint(),
                sinkConfig.getRateLimitPerSecond(),
                sinkConfig.getSimulatedLatencyMs(),
                sinkConfig.getFailureRate()
            );
            case WIDE_COLUMN_DB -> new MockWideColumnDbSink(
                sinkConfig.getName(),
                sinkConfig.getEndpoint(),
                sinkConfig.getRateLimitPerSecond(),
                sinkConfig.getSimulatedLatencyMs(),
                sinkConfig.getFailureRate()
            );
        };
    }
}
