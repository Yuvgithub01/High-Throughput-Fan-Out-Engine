package com.fanoutengine.sink;

import java.util.Map;

public final class MockWideColumnDbSink extends AbstractRateLimitedMockSink {
    public MockWideColumnDbSink(
        String name,
        String endpoint,
        double rateLimitPerSecond,
        int simulatedLatencyMs,
        double failureRate
    ) {
        super(name, SinkType.WIDE_COLUMN_DB, endpoint, rateLimitPerSecond, simulatedLatencyMs, failureRate);
    }

    @Override
    protected void validatePayload(Object payload) {
        if (!(payload instanceof Map<?, ?>)) {
            throw new IllegalArgumentException("Wide-column DB sink payload must be a CQL map");
        }
    }
}
