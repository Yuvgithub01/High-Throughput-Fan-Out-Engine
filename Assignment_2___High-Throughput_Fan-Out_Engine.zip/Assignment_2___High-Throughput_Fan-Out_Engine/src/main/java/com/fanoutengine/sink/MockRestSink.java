package com.fanoutengine.sink;

public final class MockRestSink extends AbstractRateLimitedMockSink {
    public MockRestSink(
        String name,
        String endpoint,
        double rateLimitPerSecond,
        int simulatedLatencyMs,
        double failureRate
    ) {
        super(name, SinkType.REST, endpoint, rateLimitPerSecond, simulatedLatencyMs, failureRate);
    }

    @Override
    protected void validatePayload(Object payload) {
        if (!(payload instanceof String)) {
            throw new IllegalArgumentException("REST sink payload must be a JSON string");
        }
    }
}
