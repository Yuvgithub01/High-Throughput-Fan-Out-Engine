package com.fanoutengine.sink;

public final class MockGrpcSink extends AbstractRateLimitedMockSink {
    public MockGrpcSink(
        String name,
        String endpoint,
        double rateLimitPerSecond,
        int simulatedLatencyMs,
        double failureRate
    ) {
        super(name, SinkType.GRPC, endpoint, rateLimitPerSecond, simulatedLatencyMs, failureRate);
    }

    @Override
    protected void validatePayload(Object payload) {
        if (!(payload instanceof byte[])) {
            throw new IllegalArgumentException("gRPC sink payload must be protobuf byte[]");
        }
    }
}
