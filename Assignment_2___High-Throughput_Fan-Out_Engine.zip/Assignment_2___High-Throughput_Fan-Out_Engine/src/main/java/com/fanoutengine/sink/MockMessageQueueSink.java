package com.fanoutengine.sink;

public final class MockMessageQueueSink extends AbstractRateLimitedMockSink {
    public MockMessageQueueSink(
        String name,
        String endpoint,
        double rateLimitPerSecond,
        int simulatedLatencyMs,
        double failureRate
    ) {
        super(name, SinkType.MESSAGE_QUEUE, endpoint, rateLimitPerSecond, simulatedLatencyMs, failureRate);
    }

    @Override
    protected void validatePayload(Object payload) {
        if (!(payload instanceof String)) {
            throw new IllegalArgumentException("Message queue sink payload must be XML string");
        }
    }
}
