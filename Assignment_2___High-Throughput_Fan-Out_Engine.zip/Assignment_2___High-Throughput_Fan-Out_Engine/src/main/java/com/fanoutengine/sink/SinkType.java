package com.fanoutengine.sink;

public enum SinkType {
    REST,
    GRPC,
    MESSAGE_QUEUE,
    WIDE_COLUMN_DB
}
