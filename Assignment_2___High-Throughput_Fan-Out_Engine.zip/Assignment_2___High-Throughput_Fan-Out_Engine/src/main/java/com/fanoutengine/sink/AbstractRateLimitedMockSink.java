package com.fanoutengine.sink;

import com.fanoutengine.model.SourceRecord;
import com.google.common.util.concurrent.RateLimiter;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public abstract class AbstractRateLimitedMockSink implements Sink {
    private final String name;
    private final SinkType type;
    private final String endpoint;
    private final RateLimiter rateLimiter;
    private final int simulatedLatencyMs;
    private final double failureRate;

    protected AbstractRateLimitedMockSink(
        String name,
        SinkType type,
        String endpoint,
        double rateLimitPerSecond,
        int simulatedLatencyMs,
        double failureRate
    ) {
        this.name = Objects.requireNonNull(name, "name");
        this.type = Objects.requireNonNull(type, "type");
        this.endpoint = Objects.requireNonNull(endpoint, "endpoint");
        this.rateLimiter = RateLimiter.create(rateLimitPerSecond);
        this.simulatedLatencyMs = simulatedLatencyMs;
        this.failureRate = failureRate;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public SinkType type() {
        return type;
    }

    protected String endpoint() {
        return endpoint;
    }

    @Override
    public void send(Object payload, SourceRecord sourceRecord) throws Exception {
        rateLimiter.acquire();
        validatePayload(payload);

        if (simulatedLatencyMs > 0) {
            Thread.sleep(simulatedLatencyMs);
        }
        if (ThreadLocalRandom.current().nextDouble() < failureRate) {
            throw new RuntimeException("simulated downstream failure at " + endpoint + " for sink " + name);
        }
        doSend(payload, sourceRecord);
    }

    protected void doSend(Object payload, SourceRecord sourceRecord) {
        // mock implementation intentionally does not call network/database systems.
    }

    protected abstract void validatePayload(Object payload);
}
