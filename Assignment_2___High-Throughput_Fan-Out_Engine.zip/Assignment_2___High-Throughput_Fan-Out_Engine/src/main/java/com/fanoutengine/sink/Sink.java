package com.fanoutengine.sink;

import com.fanoutengine.model.SourceRecord;

public interface Sink extends AutoCloseable {
    String name();

    SinkType type();

    void send(Object payload, SourceRecord sourceRecord) throws Exception;

    @Override
    default void close() throws Exception {
    }
}
