package com.fanoutengine.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigLoader {
    private ConfigLoader() {
    }

    public static AppConfig load(Path configPath) throws IOException {
        if (!Files.exists(configPath)) {
            throw new IllegalArgumentException("config file not found: " + configPath);
        }

        String lower = configPath.getFileName().toString().toLowerCase();
        ObjectMapper mapper = (lower.endsWith(".json") ? new ObjectMapper() : new ObjectMapper(new YAMLFactory()))
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try (var reader = Files.newBufferedReader(configPath)) {
            AppConfig config = mapper.readValue(reader, AppConfig.class);
            config.validate();
            return config;
        }
    }
}
