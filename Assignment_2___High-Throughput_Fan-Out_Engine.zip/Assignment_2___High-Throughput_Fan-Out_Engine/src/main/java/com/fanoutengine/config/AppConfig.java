package com.fanoutengine.config;

import com.fanoutengine.sink.SinkType;
import java.util.ArrayList;
import java.util.List;

public class AppConfig {
    private SourceConfig source = new SourceConfig();
    private EngineConfig engine = new EngineConfig();
    private List<SinkConfig> sinks = new ArrayList<>();

    public SourceConfig getSource() {
        return source;
    }

    public void setSource(SourceConfig source) {
        this.source = source;
    }

    public EngineConfig getEngine() {
        return engine;
    }

    public void setEngine(EngineConfig engine) {
        this.engine = engine;
    }

    public List<SinkConfig> getSinks() {
        return sinks;
    }

    public void setSinks(List<SinkConfig> sinks) {
        this.sinks = sinks;
    }

    public void validate() {
        if (source == null) {
            throw new IllegalArgumentException("source config is required");
        }
        source.validate();

        if (engine == null) {
            throw new IllegalArgumentException("engine config is required");
        }
        engine.validate();

        if (sinks == null || sinks.isEmpty()) {
            throw new IllegalArgumentException("at least one sink is required");
        }
        for (SinkConfig sink : sinks) {
            sink.validate();
        }
    }

    public enum SourceFormat {
        CSV,
        JSONL,
        FIXED
    }

    public static class SourceConfig {
        private String path;
        private SourceFormat format = SourceFormat.CSV;
        private String delimiter = ",";
        private boolean hasHeader = true;
        private List<FixedWidthColumn> fixedWidthColumns = new ArrayList<>();

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public SourceFormat getFormat() {
            return format;
        }

        public void setFormat(SourceFormat format) {
            this.format = format;
        }

        public String getDelimiter() {
            return delimiter;
        }

        public void setDelimiter(String delimiter) {
            this.delimiter = delimiter;
        }

        public boolean isHasHeader() {
            return hasHeader;
        }

        public void setHasHeader(boolean hasHeader) {
            this.hasHeader = hasHeader;
        }

        public List<FixedWidthColumn> getFixedWidthColumns() {
            return fixedWidthColumns;
        }

        public void setFixedWidthColumns(List<FixedWidthColumn> fixedWidthColumns) {
            this.fixedWidthColumns = fixedWidthColumns;
        }

        public void validate() {
            if (path == null || path.isBlank()) {
                throw new IllegalArgumentException("source.path is required");
            }
            if (format == null) {
                throw new IllegalArgumentException("source.format is required");
            }
            if (format == SourceFormat.CSV && (delimiter == null || delimiter.isBlank())) {
                throw new IllegalArgumentException("source.delimiter is required for CSV");
            }
            if (format == SourceFormat.FIXED && (fixedWidthColumns == null || fixedWidthColumns.isEmpty())) {
                throw new IllegalArgumentException("source.fixedWidthColumns is required for FIXED");
            }
            if (fixedWidthColumns != null) {
                for (FixedWidthColumn fixedWidthColumn : fixedWidthColumns) {
                    fixedWidthColumn.validate();
                }
            }
        }
    }

    public static class FixedWidthColumn {
        private String name;
        private int start;
        private int end;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getStart() {
            return start;
        }

        public void setStart(int start) {
            this.start = start;
        }

        public int getEnd() {
            return end;
        }

        public void setEnd(int end) {
            this.end = end;
        }

        public void validate() {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("fixed width column name is required");
            }
            if (start < 0 || end <= start) {
                throw new IllegalArgumentException("invalid fixed width column range for " + name);
            }
        }
    }

    public static class EngineConfig {
        private int queueCapacity = 1_000;
        private int maxRetries = 3;
        private int metricsIntervalSeconds = 5;
        private String dlqPath = "sample-data/dlq.jsonl";

        public int getQueueCapacity() {
            return queueCapacity;
        }

        public void setQueueCapacity(int queueCapacity) {
            this.queueCapacity = queueCapacity;
        }

        public int getMaxRetries() {
            return maxRetries;
        }

        public void setMaxRetries(int maxRetries) {
            this.maxRetries = maxRetries;
        }

        public int getMetricsIntervalSeconds() {
            return metricsIntervalSeconds;
        }

        public void setMetricsIntervalSeconds(int metricsIntervalSeconds) {
            this.metricsIntervalSeconds = metricsIntervalSeconds;
        }

        public String getDlqPath() {
            return dlqPath;
        }

        public void setDlqPath(String dlqPath) {
            this.dlqPath = dlqPath;
        }

        public void validate() {
            if (queueCapacity <= 0) {
                throw new IllegalArgumentException("engine.queueCapacity must be > 0");
            }
            if (maxRetries < 0) {
                throw new IllegalArgumentException("engine.maxRetries must be >= 0");
            }
            if (metricsIntervalSeconds <= 0) {
                throw new IllegalArgumentException("engine.metricsIntervalSeconds must be > 0");
            }
            if (dlqPath == null || dlqPath.isBlank()) {
                throw new IllegalArgumentException("engine.dlqPath is required");
            }
        }
    }

    public static class SinkConfig {
        private String name;
        private SinkType type;
        private boolean enabled = true;
        private String endpoint;
        private double rateLimitPerSecond = 100;
        private int simulatedLatencyMs = 10;
        private double failureRate = 0.0;
        private int workers = 1;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public SinkType getType() {
            return type;
        }

        public void setType(SinkType type) {
            this.type = type;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getEndpoint() {
            return endpoint;
        }

        public void setEndpoint(String endpoint) {
            this.endpoint = endpoint;
        }

        public double getRateLimitPerSecond() {
            return rateLimitPerSecond;
        }

        public void setRateLimitPerSecond(double rateLimitPerSecond) {
            this.rateLimitPerSecond = rateLimitPerSecond;
        }

        public int getSimulatedLatencyMs() {
            return simulatedLatencyMs;
        }

        public void setSimulatedLatencyMs(int simulatedLatencyMs) {
            this.simulatedLatencyMs = simulatedLatencyMs;
        }

        public double getFailureRate() {
            return failureRate;
        }

        public void setFailureRate(double failureRate) {
            this.failureRate = failureRate;
        }

        public int getWorkers() {
            return workers;
        }

        public void setWorkers(int workers) {
            this.workers = workers;
        }

        public void validate() {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("sink name is required");
            }
            if (type == null) {
                throw new IllegalArgumentException("sink type is required for " + name);
            }
            if (endpoint == null || endpoint.isBlank()) {
                throw new IllegalArgumentException("sink endpoint is required for " + name);
            }
            if (rateLimitPerSecond <= 0) {
                throw new IllegalArgumentException("sink rateLimitPerSecond must be > 0 for " + name);
            }
            if (simulatedLatencyMs < 0) {
                throw new IllegalArgumentException("sink simulatedLatencyMs must be >= 0 for " + name);
            }
            if (failureRate < 0 || failureRate > 1) {
                throw new IllegalArgumentException("sink failureRate must be in [0,1] for " + name);
            }
            if (workers <= 0) {
                throw new IllegalArgumentException("sink workers must be > 0 for " + name);
            }
        }
    }
}
