package com.fanoutengine.metrics;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public final class MetricsCollector {
    public static final class SinkCounters {
        private final AtomicLong success = new AtomicLong();
        private final AtomicLong failure = new AtomicLong();
        private final AtomicLong retry = new AtomicLong();

        public long success() {
            return success.get();
        }

        public long failure() {
            return failure.get();
        }

        public long retry() {
            return retry.get();
        }
    }

    private final AtomicLong sourceRecords = new AtomicLong();
    private final AtomicLong inFlight = new AtomicLong();
    private final Map<String, SinkCounters> sinkCounters = new ConcurrentHashMap<>();
    private final Instant startedAt = Instant.now();

    public void registerSink(String sinkName) {
        sinkCounters.computeIfAbsent(sinkName, key -> new SinkCounters());
    }

    public void incrementSourceRecords() {
        sourceRecords.incrementAndGet();
    }

    public long sourceRecords() {
        return sourceRecords.get();
    }

    public void incrementInFlight() {
        inFlight.incrementAndGet();
    }

    public void decrementInFlight() {
        inFlight.decrementAndGet();
    }

    public long inFlight() {
        return inFlight.get();
    }

    public void recordSuccess(String sinkName) {
        sinkCounters.computeIfAbsent(sinkName, key -> new SinkCounters()).success.incrementAndGet();
    }

    public void recordFailure(String sinkName) {
        sinkCounters.computeIfAbsent(sinkName, key -> new SinkCounters()).failure.incrementAndGet();
    }

    public void recordRetry(String sinkName) {
        sinkCounters.computeIfAbsent(sinkName, key -> new SinkCounters()).retry.incrementAndGet();
    }

    public Map<String, SinkCounters> sinkCounters() {
        return sinkCounters;
    }

    public void startConsoleReporting(ScheduledExecutorService scheduler, int intervalSeconds) {
        scheduler.scheduleAtFixedRate(this::printSnapshot, intervalSeconds, intervalSeconds, TimeUnit.SECONDS);
    }

    public void printSnapshot() {
        long processed = sourceRecords.get();
        double elapsedSeconds = Math.max(1.0, Duration.between(startedAt, Instant.now()).toMillis() / 1000.0);
        double throughput = processed / elapsedSeconds;

        StringBuilder sb = new StringBuilder();
        sb.append("[METRICS] records=").append(processed)
            .append(" throughput=").append(String.format("%.2f", throughput)).append("/sec")
            .append(" inFlight=").append(inFlight.get());

        for (Map.Entry<String, SinkCounters> entry : sinkCounters.entrySet()) {
            SinkCounters counters = entry.getValue();
            sb.append(" | ").append(entry.getKey())
                .append(": success=").append(counters.success())
                .append(", failure=").append(counters.failure())
                .append(", retry=").append(counters.retry());
        }
        System.out.println(sb);
    }
}
