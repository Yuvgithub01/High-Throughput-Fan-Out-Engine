package com.fanoutengine.transform;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.sink.SinkType;

public final class TransformerFactory {
    private final ObjectMapper objectMapper;

    public TransformerFactory(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public SinkTransformer create(SinkType sinkType) {
        return switch (sinkType) {
            case REST -> new JsonSinkTransformer(objectMapper);
            case GRPC -> new ProtobufSinkTransformer();
            case MESSAGE_QUEUE -> new XmlSinkTransformer();
            case WIDE_COLUMN_DB -> new WideColumnSinkTransformer();
        };
    }
}
