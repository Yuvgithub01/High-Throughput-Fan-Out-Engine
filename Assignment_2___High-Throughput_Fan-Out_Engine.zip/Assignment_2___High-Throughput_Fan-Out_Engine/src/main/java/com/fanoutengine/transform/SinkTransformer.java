package com.fanoutengine.transform;

import com.fanoutengine.model.SourceRecord;

public interface SinkTransformer {
    Object transform(SourceRecord sourceRecord) throws Exception;
}
