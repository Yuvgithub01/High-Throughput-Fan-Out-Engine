package com.fanoutengine.transform;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.model.SourceRecord;
import java.util.LinkedHashMap;
import java.util.Map;

public final class JsonSinkTransformer implements SinkTransformer {
    private final ObjectMapper objectMapper;

    public JsonSinkTransformer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public Object transform(SourceRecord sourceRecord) throws Exception {
        Map<String, Object> payload = new LinkedHashMap<>(sourceRecord.getFields());
        payload.put("_sourceLine", sourceRecord.getLineNumber());
        payload.put("_transformedFor", "REST");
        return objectMapper.writeValueAsString(payload);
    }
}
