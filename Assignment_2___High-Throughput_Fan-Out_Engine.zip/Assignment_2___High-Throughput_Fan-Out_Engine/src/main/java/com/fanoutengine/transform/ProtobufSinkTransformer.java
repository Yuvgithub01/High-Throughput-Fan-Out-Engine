package com.fanoutengine.transform;

import com.fanoutengine.model.SourceRecord;
import com.google.protobuf.NullValue;
import com.google.protobuf.Struct;
import com.google.protobuf.Value;
import java.util.Map;

public final class ProtobufSinkTransformer implements SinkTransformer {
    @Override
    public Object transform(SourceRecord sourceRecord) {
        Struct.Builder builder = Struct.newBuilder();
        for (Map.Entry<String, Object> entry : sourceRecord.getFields().entrySet()) {
            builder.putFields(entry.getKey(), toValue(entry.getValue()));
        }
        builder.putFields("_sourceLine", Value.newBuilder().setNumberValue(sourceRecord.getLineNumber()).build());
        builder.putFields("_transformedFor", Value.newBuilder().setStringValue("GRPC").build());
        return builder.build().toByteArray();
    }

    private Value toValue(Object value) {
        if (value == null) {
            return Value.newBuilder().setNullValue(NullValue.NULL_VALUE).build();
        }
        if (value instanceof Boolean bool) {
            return Value.newBuilder().setBoolValue(bool).build();
        }
        if (value instanceof Number number) {
            return Value.newBuilder().setNumberValue(number.doubleValue()).build();
        }
        return Value.newBuilder().setStringValue(value.toString()).build();
    }
}
