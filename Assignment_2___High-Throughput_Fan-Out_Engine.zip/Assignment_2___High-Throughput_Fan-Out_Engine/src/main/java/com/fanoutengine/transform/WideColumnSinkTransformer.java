package com.fanoutengine.transform;

import com.fanoutengine.model.SourceRecord;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public final class WideColumnSinkTransformer implements SinkTransformer {
    @Override
    public Object transform(SourceRecord sourceRecord) {
        Map<String, Object> cqlMap = new LinkedHashMap<>();
        cqlMap.put("pk", sourceRecord.idOrDefault());
        cqlMap.put("source_line", sourceRecord.getLineNumber());
        cqlMap.put("ingested_at", Instant.now().toString());
        cqlMap.put("attributes", sourceRecord.getFields());
        cqlMap.put("transformed_for", "WIDE_COLUMN_DB");
        return cqlMap;
    }
}
