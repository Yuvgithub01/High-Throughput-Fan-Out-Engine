package com.fanoutengine.transform;

import com.fanoutengine.model.SourceRecord;
import java.util.Map;

public final class XmlSinkTransformer implements SinkTransformer {
    @Override
    public Object transform(SourceRecord sourceRecord) {
        StringBuilder xml = new StringBuilder();
        xml.append("<record transformedFor=\"MQ\" sourceLine=\"").append(sourceRecord.getLineNumber()).append("\">");
        for (Map.Entry<String, Object> entry : sourceRecord.getFields().entrySet()) {
            xml.append("<").append(escapeTag(entry.getKey())).append(">");
            xml.append(escapeText(entry.getValue() == null ? "" : entry.getValue().toString()));
            xml.append("</").append(escapeTag(entry.getKey())).append(">");
        }
        xml.append("</record>");
        return xml.toString();
    }

    private String escapeText(String value) {
        return value
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;");
    }

    private String escapeTag(String key) {
        return key.replaceAll("[^A-Za-z0-9_\\-]", "_");
    }
}
