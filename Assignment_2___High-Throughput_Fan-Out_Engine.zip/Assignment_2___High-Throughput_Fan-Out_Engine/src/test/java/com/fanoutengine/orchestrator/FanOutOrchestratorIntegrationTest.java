package com.fanoutengine.orchestrator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.config.AppConfig;
import com.fanoutengine.dlq.FileDeadLetterQueue;
import com.fanoutengine.ingest.CsvRecordReader;
import com.fanoutengine.metrics.MetricsCollector;
import com.fanoutengine.sink.Sink;
import com.fanoutengine.sink.SinkType;
import com.fanoutengine.transform.JsonSinkTransformer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class FanOutOrchestratorIntegrationTest {
    @TempDir
    Path tempDir;

    @Test
    void orchestratorRetriesAndCompletesWithMockitoSink() throws Exception {
        Path input = tempDir.resolve("input.csv");
        Files.writeString(
            input,
            "id,name%n1,alpha%n2,beta%n".formatted()
        );

        Sink sink = mock(Sink.class);
        when(sink.name()).thenReturn("mock-rest");
        when(sink.type()).thenReturn(SinkType.REST);

        AtomicInteger calls = new AtomicInteger(0);
        doAnswer(invocation -> {
            if (calls.getAndIncrement() == 0) {
                throw new RuntimeException("transient failure");
            }
            return null;
        }).when(sink).send(any(), any());

        SinkChannel channel = new SinkChannel(
            "mock-rest",
            sink,
            new JsonSinkTransformer(new ObjectMapper()),
            16,
            1
        );

        AppConfig.EngineConfig engine = new AppConfig.EngineConfig();
        engine.setQueueCapacity(16);
        engine.setMaxRetries(3);
        engine.setMetricsIntervalSeconds(60);
        engine.setDlqPath(tempDir.resolve("dlq.jsonl").toString());

        FanOutOrchestrator orchestrator = new FanOutOrchestrator(
            new CsvRecordReader(input, ",", true),
            List.of(channel),
            engine,
            new MetricsCollector(),
            new FileDeadLetterQueue(new ObjectMapper(), Path.of(engine.getDlqPath()))
        );

        FanOutResult result = orchestrator.run();

        assertEquals(2, result.sourceRecords());
        assertEquals(0, result.inFlight());
        assertEquals(2, result.sinkSummary().get("mock-rest").success());
        assertEquals(0, result.sinkSummary().get("mock-rest").failure());
        assertEquals(1, result.sinkSummary().get("mock-rest").retry());
        verify(sink, atLeast(3)).send(any(), any());
    }
}
