package com.fanoutengine.transform;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fanoutengine.model.SourceRecord;
import java.util.Map;
import org.junit.jupiter.api.Test;

class JsonSinkTransformerTest {
    private static final TypeReference<Map<String, Object>> MAP_TYPE = new TypeReference<>() {
    };

    @Test
    void transformsRecordToJsonPayload() throws Exception {
        SourceRecord record = new SourceRecord(7, Map.of("id", "7", "name", "alpha"));
        JsonSinkTransformer transformer = new JsonSinkTransformer(new ObjectMapper());

        String json = (String) transformer.transform(record);
        Map<String, Object> payload = new ObjectMapper().readValue(json, MAP_TYPE);

        assertEquals("7", payload.get("id"));
        assertEquals("alpha", payload.get("name"));
        assertEquals("REST", payload.get("_transformedFor"));
        assertEquals(7, ((Number) payload.get("_sourceLine")).intValue());
    }
}
