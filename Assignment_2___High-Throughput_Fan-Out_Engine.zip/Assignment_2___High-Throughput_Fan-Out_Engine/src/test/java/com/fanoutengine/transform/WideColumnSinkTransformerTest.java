package com.fanoutengine.transform;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fanoutengine.model.SourceRecord;
import java.util.Map;
import org.junit.jupiter.api.Test;

class WideColumnSinkTransformerTest {
    @Test
    void transformsRecordToWideColumnMap() throws Exception {
        SourceRecord record = new SourceRecord(11, Map.of("id", "k-11", "name", "wide"));
        WideColumnSinkTransformer transformer = new WideColumnSinkTransformer();

        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) transformer.transform(record);

        assertEquals("k-11", payload.get("pk"));
        assertEquals(11L, payload.get("source_line"));
        assertEquals("WIDE_COLUMN_DB", payload.get("transformed_for"));
        assertTrue(payload.containsKey("attributes"));
    }
}
