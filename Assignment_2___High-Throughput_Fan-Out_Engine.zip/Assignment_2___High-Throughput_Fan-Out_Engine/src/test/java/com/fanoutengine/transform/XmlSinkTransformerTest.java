package com.fanoutengine.transform;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fanoutengine.model.SourceRecord;
import java.util.Map;
import org.junit.jupiter.api.Test;

class XmlSinkTransformerTest {
    @Test
    void transformsRecordToXml() throws Exception {
        SourceRecord record = new SourceRecord(9, Map.of("id", "9", "name", "a&b"));
        XmlSinkTransformer transformer = new XmlSinkTransformer();

        String xml = (String) transformer.transform(record);

        assertTrue(xml.contains("<id>9</id>"));
        assertTrue(xml.contains("<name>a&amp;b</name>"));
        assertTrue(xml.contains("transformedFor=\"MQ\""));
    }
}
