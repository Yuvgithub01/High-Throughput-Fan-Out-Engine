package com.fanoutengine.transform;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fanoutengine.model.SourceRecord;
import com.google.protobuf.Struct;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ProtobufSinkTransformerTest {
    @Test
    void transformsRecordToProtobufBytes() throws Exception {
        SourceRecord record = new SourceRecord(5, Map.of("id", "42", "active", true, "amount", 8.5));
        ProtobufSinkTransformer transformer = new ProtobufSinkTransformer();

        byte[] payload = (byte[]) transformer.transform(record);
        Struct parsed = Struct.parseFrom(payload);

        assertEquals("42", parsed.getFieldsOrThrow("id").getStringValue());
        assertEquals(true, parsed.getFieldsOrThrow("active").getBoolValue());
        assertEquals(8.5, parsed.getFieldsOrThrow("amount").getNumberValue());
        assertEquals("GRPC", parsed.getFieldsOrThrow("_transformedFor").getStringValue());
    }
}
